package com.cts.authenticationservice.controllers;

import com.cts.authenticationservice.entities.ApplicationUser;
import com.cts.authenticationservice.services.AuthService;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/login")
    public ResponseEntity<String> authenticate(@RequestBody ApplicationUser user){
        boolean isValid=authService.validate(user.getUserName(),user.getPassword());
        ResponseEntity<String> responseEntity=null;
        if(isValid)
        {
            responseEntity=new ResponseEntity<>("valid user", HttpStatus.OK);
        }
        else
        {
            responseEntity=new ResponseEntity<>("Invalid User",HttpStatus.BAD_REQUEST);
        }
        return responseEntity;
    }
    
    @RequestMapping(value="/allUsers",method = RequestMethod.GET)
	public List<ApplicationUser> allUsers(){
		
		
		return authService.allUsers();
		
		
	}
}
